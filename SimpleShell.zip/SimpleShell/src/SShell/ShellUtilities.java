package SShell;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class ShellUtilities {

	public static List<String> commands = Arrays.asList("ls", "cd", "echo", "ping", "ifconfig", "ipconfig");

	public static boolean acceptCommand(String command) {
		if (commands.contains(command)) {
			return true;

		} else
			return false;
	}
	
	//implement update history
	public static void updateHistory(ArrayList history) {
		
	}

}
