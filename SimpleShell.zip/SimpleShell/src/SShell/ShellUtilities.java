package SShell;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Arrays;
import java.util.List;

public class ShellUtilities {

	public static List<String> commands = Arrays.asList("ls", "cd", "echo", "ping", "ifconfig", "ipconfig");

	public static boolean acceptCommand(String command) {
		if (commands.contains(command)) {
			return true;

		} else
			return false;
	}

	public static boolean verifyPath(String path) {

		try {

			ProcessBuilder pathRetrieve = new ProcessBuilder("/bin/sh", "-c", "pwd");
			pathRetrieve.directory(new File(path));
			Process pathProcess = pathRetrieve.start();

			String s = null;

			BufferedReader stdInput = new BufferedReader(new InputStreamReader(pathProcess.getInputStream()));
			// read path argument
			s = stdInput.readLine();

			System.out.println("curr dir :" + s);

			return true;

		} catch (IOException e) {
			System.out.println("cd exception happened -> Here's what I know: ");
			System.out.println("No such file or directory (\'" + path + "\')");
			System.out.println(e);
			return false;
		}

	}

}
