
package SShell;

import java.io.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Map;
import java.util.regex.Pattern;

/* References
By Alvin Alexander => https://alvinalexander.com/java/edu/pj/pj010016

*/

public class SShell {

	public static void main(String[] args) throws java.io.IOException {

		String currDir = "";
		ProcessBuilder homePath = new ProcessBuilder("/bin/sh", "-c", "pwd");
		Process homePathProcess = homePath.start();

		BufferedReader pathStdInput = new BufferedReader(new InputStreamReader(homePathProcess.getInputStream()));

		// read path argument
		currDir = pathStdInput.readLine();

		String commandLine;
		BufferedReader console = new BufferedReader(new InputStreamReader(System.in));

		while (true) {

			if (currDir.equals("")) {
				System.out.print("Simple_Shell:~ >>");
			} else {
				System.out.print("Simple_Shell:" + currDir + " >>");
			}
			// read what the user entered
			commandLine = console.readLine();

			// if the user entered a return, just loop again
			if (commandLine.equals("")) {
				continue;
			} else if (commandLine.equalsIgnoreCase("exit")) {
				System.out.println("Goodbye");
				System.exit(0);
			}

			// split multiple commands
			String[] multicommands = commandLine.split(Pattern.quote(" ^ "));

			// iterate over all the commands
			for (String commandp : multicommands) {

				System.out.println("Command to exec: " + commandp);
				// split the string into a string array
				ArrayList<String> parameters = new ArrayList<String>();
				String[] lineSplit = commandp.split(" ");

				for (String word : lineSplit) {
					// System.out.println("word:" + word);
					parameters.add(word);
				}

				String currCommand = parameters.get(0);
				// check if command has been implemented
				if (ShellUtilities.acceptCommand(currCommand)) {

					// check if its cd command -> yet to fix
					if (currCommand.equals("cd")) {
						//System.out.println("command cd activated: ");

						// check if path is provided
						if (parameters.size() != 1) {
							String pathArgument = parameters.get(1);

							if (pathArgument.startsWith("..")) {
								//System.out.println("return intro");
								String[] parentSplit = pathArgument.split("/");

								File wDir = new File(currDir);

								for (String word : parentSplit) {

									if (wDir.getAbsolutePath().equals("/"))
										break;

									wDir = wDir.getParentFile();
								}

								System.out.println("Path after parsing: " + wDir.toString());
								
								
								currDir = wDir.toString();

							}
							
							else {
								// get absolute path and update current directory
//								File absPath = new File(s);
//								currDir = absPath.getAbsolutePath();
								
							}

							

//							if (pathArgument.equals("..")) {
//								System.out.println(".. argument");
//								
//								ProcessBuilder getPath = new ProcessBuilder("pwd");
//								
//								Process retrievePath = getPath.start();
//								
//								String p = null;
//
//								BufferedReader stdInput = new BufferedReader(new InputStreamReader(retrievePath.getInputStream()));
//
//								BufferedReader stdError = new BufferedReader(new InputStreamReader(retrievePath.getErrorStream()));
//
//								
//								//obtain path from response
//								
//								// read the output from the command
//								System.out.println("\nHere is the standard output of the command:\n");
//								while ((p = stdInput.readLine()) != null) {
//									System.out.println(p);
//									System.out.println("line");
//								}
//								
//								
//
//							}

						} else {
							System.out.println("solo cd");
						}

					}

				} else {
					System.out.println("Command \'" + currCommand + "\' not implemented");
				}

			}

			//THE REST IS TO IMPLEMENT NEXT COMMADS

//			ArrayList<String> parms = new ArrayList<String>();
//			String[] lineSplit = commandLine.split(" ");
//
//			int size = lineSplit.length;
//			for (int i = 0; i < size; i++) {
//				// System.out.println(lineSplit[i]);
//				parms.add(lineSplit[i]);
//			}
//
//			if (parms.get(0).equals("cd")) {
//
//				ProcessBuilder processBuilder = new ProcessBuilder("/bin/sh", "-c", "pwd");
//
//				processBuilder.directory(new File(parms.get(1)));
//				Process process = processBuilder.start();
//
//				String s = null;
//
//				BufferedReader stdInput = new BufferedReader(new InputStreamReader(process.getInputStream()));
//
//				BufferedReader stdError = new BufferedReader(new InputStreamReader(process.getErrorStream()));
//
//				// read the output from the command
//				System.out.println("\nHere is the standard output of the command:\n");
//				while ((s = stdInput.readLine()) != null) {
//					System.out.println(s);
//				}
//
//				// read any errors from the attempted command
//				System.out.println("\nHere is the standard error of the command (if any):\n");
//				while ((s = stdError.readLine()) != null) {
//					System.out.println(s);
//				}
//
//				continue;
//
//			}
//
//			try {
//
//				String s = null;
//
//				// using the Runtime exec method:
//				// Process p = Runtime.getRuntime().exec(commandLine);
//
//				ProcessBuilder pb = new ProcessBuilder(parms);
//
////				Map<String, String> environment = pb.environment();
////				environment.forEach((key, value) -> System.out.println(key + value));
//
//				// pb.directory(new File("/Documents/USFQ"));
//
//				Process proc = pb.start();
//
//				BufferedReader stdInput = new BufferedReader(new InputStreamReader(proc.getInputStream()));
//
//				BufferedReader stdError = new BufferedReader(new InputStreamReader(proc.getErrorStream()));
//
//				// read the output from the command
//				System.out.println("\nHere is the standard output of the command:\n");
//				while ((s = stdInput.readLine()) != null) {
//					System.out.println(s);
//				}
//
//				// read any errors from the attempted command
//				System.out.println("\nHere is the standard error of the command (if any):\n");
//				while ((s = stdError.readLine()) != null) {
//					System.out.println(s);
//				}
//
//				// System.exit(0);
//			}
//
//			catch (IOException e) {
//				System.out.println("exception happened - here's what I know: ");
//				System.out.println(e.getMessage());
//				// e.printStackTrace();
//				// System.exit(-1);
//			}

//			String s = null;
//
//			try {
//
//				// using the Runtime exec method:
//				// Process p = Runtime.getRuntime().exec(commandLine);
//
//				ProcessBuilder pb = new ProcessBuilder(parms);
//				
//				Map<String, String> environment = pb.environment();
//				environment.forEach((key, value) -> System.out.println(key + value));
//				
//				Process proc = pb.start();
//
//				BufferedReader stdInput = new BufferedReader(new InputStreamReader(proc.getInputStream()));
//
//				BufferedReader stdError = new BufferedReader(new InputStreamReader(proc.getErrorStream()));
//
//				// read the output from the command
//				System.out.println("\nHere is the standard output of the command:\n");
//				while ((s = stdInput.readLine()) != null) {
//					System.out.println(s);
//				}
//
//				// read any errors from the attempted command
//				System.out.println("\nHere is the standard error of the command (if any):\n");
//				while ((s = stdError.readLine()) != null) {
//					System.out.println(s);
//				}
//
//				// System.exit(0);
//			}
//
//			catch (IOException e) {
//				System.out.println("exception happened - here's what I know: ");
//				System.out.println(e);
//				//e.printStackTrace();
//				// System.exit(-1);
//			}

//			ProcessBuilder pb = new ProcessBuilder(parms);
//			Process proc = pb.start();
//
//			// obtain the input stream
//			InputStream is = proc.getInputStream();
//			InputStreamReader isr = new InputStreamReader(is);
//			BufferedReader br = new BufferedReader(isr);
//
//			// read what is returned by the command
//			String line;
//			while ((line = br.readLine()) != null)
//				System.out.println(line);
//
//			br.close();

		}

		// String s = null;

//		try {
//
//			// using the Runtime exec method:
//			Process p = Runtime.getRuntime().exec("ifconfig");
//
//			BufferedReader stdInput = new BufferedReader(new InputStreamReader(p.getInputStream()));
//
//			BufferedReader stdError = new BufferedReader(new InputStreamReader(p.getErrorStream()));
//
//			// read the output from the command
//			System.out.println("Here is the standard output of the command:\n");
//			while ((s = stdInput.readLine()) != null) {
//				System.out.println(s);
//			}
//
//			// read any errors from the attempted command
//			System.out.println("Here is the standard error of the command (if any):\n");
//			while ((s = stdError.readLine()) != null) {
//				System.out.println(s);
//			}
//
//			System.exit(0);
//		}
//
//		catch (IOException e) {
//			System.out.println("exception happened - here's what I know: ");
//			e.printStackTrace();
//			System.exit(-1);
//		}

	}

}
