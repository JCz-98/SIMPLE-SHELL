package SShell;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class ShellUtilities {

	public static List<String> commands = Arrays.asList("ls", "cd", "echo", "ping", "ifconfig", "ipconfig", "history");

	public static boolean acceptCommand(String command) {
		if (commands.contains(command)) {
			return true;

		} else
			return false;
	}

	public static void runCommand(List parameters, String dir) {

		try {
			ProcessBuilder processBuilder = new ProcessBuilder(parameters);

			processBuilder.directory(new File(dir));
			Process process = processBuilder.start();

			String s = null;

			BufferedReader stdInput = new BufferedReader(new InputStreamReader(process.getInputStream()));

			BufferedReader stdError = new BufferedReader(new InputStreamReader(process.getErrorStream()));

			// read the output from the command
			System.out.println();
			while ((s = stdInput.readLine()) != null) {
				System.out.println(s);
			}

			// read any errors from the attempted command
			while ((s = stdError.readLine()) != null) {
				System.out.println(s);
			}

		} catch (IOException e) {
			System.out.println("'" + parameters.get(0) + "' exception happened - here's what I know: ");
			System.out.println(e.toString());
		}

	}

	// implement update history
	public static void updateHistory(ArrayList history) {
		
	}

}
